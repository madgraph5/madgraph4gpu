//==========================================================================
// This file has been automatically generated for CUDA/C++ standalone by
// MadGraph5_aMC@NLO v. 3.3.1_lo_vect, 2022-01-30
// By the MadGraph5_aMC@NLO Development Team
// Visit launchpad.net/madgraph5 and amcatnlo.web.cern.ch
//==========================================================================

#ifndef MG5_Sigma_sm_gg_ttx_H
#define MG5_Sigma_sm_gg_ttx_H 1

#include "mgOnGpuConfig.h"

#include "mgOnGpuVectors.h"

#include "Parameters_sm.h"

#include <vector>

//--------------------------------------------------------------------------

#ifdef __CUDACC__
namespace mg5amcGpu
#else
namespace mg5amcCpu
#endif
{
  //==========================================================================
  // A class for calculating the matrix elements for
  // Process: g g > t t~ WEIGHTED<=2 @1
  //--------------------------------------------------------------------------

  class CPPProcess
  {
  public: /* clang-format off */

    // Constructor (from command line arguments)
    CPPProcess( bool verbose = false, bool debug = false );

    // Destructor
    ~CPPProcess();

    // Initialize process (read model parameters from file)
    virtual void initProc( const std::string& param_card_name );

    // Retrieve the compiler that was used to build this module
    static const std::string getCompiler();

    // Other methods of this instance (???)
    //const std::vector<fptype>& getMasses() const { return m_masses; }
    //virtual int code() const{ return 1; }
    //void setInitial( int inid1, int inid2 ){ id1 = inid1; id2 = inid2; }
    //int getDim() const { return dim; }
    //int getNIOParticles() const { return nexternal; } // nexternal was nioparticles

    // Accessors (unused so far: add four of them only to fix a clang build warning)
    //bool verbose() const { return m_verbose; }
    bool debug() const { return m_debug; }

  public: /* clang-format on */

    // Hardcoded parameters for this process (constant class variables)
    //static const int ninitial = mgOnGpu::npari;
    //static const int nexternal = 4; // mgOnGpu::npar (nexternal was nioparticles)
    //static const int nprocesses = 1; // FIXME: assume process.nprocesses == 1
    //static const int nwavefuncs = 6; // mgOnGpu::nwf
    //static const int namplitudes = 3;
    //static const int ncomb = 16; // mgOnGpu::ncomb
    //static const int wrows = 5; // mgOnGpu::nw6;

  private:

    // Command line arguments (constructor)
    bool m_verbose;
    bool m_debug;

    // Physics model parameters to be read from file (initProc function)
#ifndef MGONGPU_HARDCODE_CIPC
    Parameters_sm* m_pars;
#endif
    std::vector<fptype> m_masses; // external particle masses

    // Other variables of this instance (???)
    //int id1, id2; // initial particle ids
    //cxtype** amp; // ???
  };

  //--------------------------------------------------------------------------

#ifdef __CUDACC__
  __global__ void
  sigmaKin_getGoodHel( const fptype* allmomenta, // input: momenta[nevt*npar*4]
                       fptype* allMEs,           // output: allMEs[nevt], |M|^2 final_avg_over_helicities
                       bool* isGoodHel );        // output: isGoodHel[ncomb] - device array
#else
  __global__ void
  sigmaKin_getGoodHel( const fptype* allmomenta, // input: momenta[nevt*npar*4]
                       fptype* allMEs,           // output: allMEs[nevt], |M|^2 final_avg_over_helicities
                       bool* isGoodHel,          // output: isGoodHel[ncomb] - device array
                       const int nevt );         // input: #events (for cuda: nevt == ndim == gpublocks*gputhreads)
#endif

  //--------------------------------------------------------------------------

  void
  sigmaKin_setGoodHel( const bool* isGoodHel ); // input: isGoodHel[ncomb] - host array

  //--------------------------------------------------------------------------

#ifdef __CUDACC__
  __global__ void
  sigmaKin( const fptype* allmomenta, // input: momenta[nevt*npar*4]
            fptype* allMEs );         // output: allMEs[nevt], |M|^2 final_avg_over_helicities
#else
  __global__ void
  sigmaKin( const fptype* allmomenta, // input: momenta[nevt*npar*4]
            fptype* allMEs,           // output: allMEs[nevt], |M|^2 final_avg_over_helicities
            const int nevt );         // input: #events (for cuda: nevt == ndim == gpublocks*gputhreads)
#endif

  //--------------------------------------------------------------------------
}

#endif // MG5_Sigma_sm_gg_ttx_H
